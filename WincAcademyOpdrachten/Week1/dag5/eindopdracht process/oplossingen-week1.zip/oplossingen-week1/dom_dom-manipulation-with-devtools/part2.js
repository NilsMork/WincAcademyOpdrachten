const paragraphElement = document.getElementById("first-section");
console.log(paragraphElement);
