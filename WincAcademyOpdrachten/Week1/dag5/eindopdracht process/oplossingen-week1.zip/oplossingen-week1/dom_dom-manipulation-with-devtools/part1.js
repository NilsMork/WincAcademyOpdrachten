document.body.innerHTML = "Ik ben de nieuwe inhoud van body";
