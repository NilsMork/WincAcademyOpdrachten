const paragraphElements = document.getElementsByClassName("paragraph");
console.log(paragraphElements);
