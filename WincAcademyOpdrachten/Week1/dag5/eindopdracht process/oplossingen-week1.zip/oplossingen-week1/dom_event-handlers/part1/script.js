const alertButton = document.getElementById("mybutton");
alertButton.addEventListener("click", function () {
  alert("button clicked!");
});
