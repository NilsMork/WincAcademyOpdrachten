// Dit is een grote som

console.log(1230941 * 1823794);
console.log(637263 / 54);

/* Ik ben een blok comment
console.log(1230941 * 1823794);
console.log(637263 / 54);
*/

// Code die niet "aan" staat zie je niet in de console.

// Let op: runt JavaScript in Node? Dan is je terminal de console.
// Runt JavaScript in je browser? Dan vind je de console in je developer tools.
