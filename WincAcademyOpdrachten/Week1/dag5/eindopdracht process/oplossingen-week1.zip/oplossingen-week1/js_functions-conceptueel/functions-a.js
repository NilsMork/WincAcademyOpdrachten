// Make a sandwhich
// step 1 Put butter on the sandwhich
// step 2 add cheese to the sandwhich
// step 3 fold the sandwhich for a very Dutch experience

const makeSandwichWithCheese = function() {
  console.log("Put butter on sandwich");
  console.log("Add cheese to sandwich");
  console.log("Fold the sandwich for a very Dutch Experience");
};

makeSandwichWithCheese();
