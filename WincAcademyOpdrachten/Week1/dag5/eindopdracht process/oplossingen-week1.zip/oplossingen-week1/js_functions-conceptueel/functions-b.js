const makeSandwich = function(topping) {
  console.log("Put butter on sandwich");
  console.log("Add" + topping + "to sandwich");
  console.log("Fold the sandwich for a very Dutch Experience");
  console.log("There you go, a sandwich with... " + topping);
};

makeSandwich("pindakaas");
